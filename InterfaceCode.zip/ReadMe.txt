The data for the metabolomics case study are not included, though the file 'cassgam.stan' contains Stan code to implement the model.

The script 'alonscript.R' contains the code for the gene expression case study.

Stan code for the grouped predictor case study (simulation study) is in the file 'simcasshered.stan'

'compare_methods_sim.R' implements the simulation study